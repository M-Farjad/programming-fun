public class Chef extends Employee {
    private String chefId;
    private String orderId;

    public String getChefId() {
        return chefId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setChefId(String chefId) {
        this.chefId = chefId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
