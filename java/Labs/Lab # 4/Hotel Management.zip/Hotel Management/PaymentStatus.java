enum PaymentStatus {
    PENDING,
    SUCCESSFUL,
    FAILED
}